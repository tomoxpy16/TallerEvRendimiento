#ifndef FUNCIONES_H
#define FUNCIONES_H

#include <sys/time.h>

//declaracion
void InicioMuestra();
void FinMuestra();
void iniMatrix(double *mA, double *mB, int D);
void impMatrix(double *matrix, int D);


#endif 